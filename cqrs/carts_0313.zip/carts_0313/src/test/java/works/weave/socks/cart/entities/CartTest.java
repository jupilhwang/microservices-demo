package works.weave.socks.cart.entities;


import org.axonframework.test.aggregate.AggregateTestFixture;
import org.axonframework.test.aggregate.FixtureConfiguration;
import org.junit.Before;
import org.junit.Test;
import works.weave.socks.cart.axon.AddItemCommand;
import works.weave.socks.cart.axon.CartCreatedEvent;
import works.weave.socks.cart.axon.CreateCartCommand;
import works.weave.socks.cart.axon.ItemAddedEvent;

public class CartTest {

    private FixtureConfiguration fixture;
    @Before
    public void setUp() throws Exception {
        fixture = new AggregateTestFixture(Cart.class);
    }

    @Test
    public void testCreateAccount() throws Exception {
        fixture.givenNoPriorActivity()
                .when(new CreateCartCommand("1234"))
                .expectEvents(new CartCreatedEvent("1234"));
    }

    @Test
    public void testAddItem() throws Exception{
        fixture.given(new CartCreatedEvent("1234"))
                .when(new AddItemCommand("1234", new Item("id","itemid",1, 1000 )))
                .expectEvents(new ItemAddedEvent("1234", new Item("id","itemid",1, 1000 )));

    }



/*
    @Test
    public void testAddItem(){
        fixture.given(new CartCreatedEvent("1234", 1000))
                .when(new ItemAddCommand("1234", 600))
                .expectEvents(new ItemAddedEvent("1234", 600, 400));

    }
*/

}
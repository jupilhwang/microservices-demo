package works.weave.socks.cart.axon

import org.axonframework.commandhandling.TargetAggregateIdentifier

import works.weave.socks.cart.entities.Item

class CreateCartCommand(val customerId:String);
class AddItemCommand(@TargetAggregateIdentifier val customerId:String, val item: Item)
class RemoveItemCommand(val customerId:String,  val item: Item)


class CartCreatedEvent(val customerId:String)
class ItemAddedEvent(val customerId:String, val item: Item)
class ItemDeletedEvent(val customerId:String, val item: Item)



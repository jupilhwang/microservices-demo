#!/bin/bash

#mvn build
mvn clean package

#docker image build
docker build --tag dockerdang/carts:0.3.1 .
docker push dockerdang/carts:0.3.1

# docker-compose up 
docker-compose -f /home/daniel/Dev-Study/weave-sockshop/microservices-demo/deploy/docker-compose/docker-compose_new.yml up -d
